

module geneticos {
	exports us.lsi.ag.agchromosomes;
	exports us.lsi.ag.agstopping;
	exports us.lsi.sa;
	exports us.lsi.ag.agoperators;
	exports us.lsi.ag;

	requires transitive commons.math3;
	requires transitive org.jgrapht.core;
	requires transitive partecomun;
	requires transitive grafos;
}