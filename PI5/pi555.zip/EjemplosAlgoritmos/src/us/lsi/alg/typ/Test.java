package us.lsi.alg.typ;

import us.lsi.common.List2;

public class Test {

	public static void main(String[] args) {
		System.out.println(List2.rangeList(0, 5));
		System.out.println(List2.rangeList(0, 10,3));
	}

}
