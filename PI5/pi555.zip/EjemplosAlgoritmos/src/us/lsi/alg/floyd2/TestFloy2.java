package us.lsi.alg.floyd2;

import java.util.Locale;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.GraphWalk;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.graph.SimpleWeightedGraph;
import us.lsi.common.String2;
import us.lsi.common.Union;
import us.lsi.grafos.datos.Carretera;
import us.lsi.grafos.datos.Ciudad;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;
import us.lsi.graphs.SimpleEdge;
import us.lsi.graphs.views.IntegerVertexGraphView;
import us.lsi.hypergraphs2.Datos;
import us.lsi.hypergraphs2.GraphTree2;

public class TestFloy2 {
	
	public static Ciudad ciudad(Graph<Ciudad,Carretera> graph, String nombre) {
		return graph.vertexSet().stream().filter(c->c.nombre().equals(nombre)).findFirst().get();
	}
	
	public static SimpleWeightedGraph<Ciudad, Carretera> leeDatos(String fichero) {
		SimpleWeightedGraph<Ciudad, Carretera> graph = GraphsReader.newGraph(fichero, 
				Ciudad::ofFormat, 
				Carretera::ofFormat,
				Graphs2::simpleWeightedGraph, 
				Carretera::km);
		return graph;
	}

	public static void main(String[] args) {
		Locale.setDefault(new Locale("en", "US"));
		
		SimpleWeightedGraph<Ciudad, Carretera> graph = leeDatos("./ficheros/andalucia.txt");
		IntegerVertexGraphView<Ciudad,Carretera> graph2 = IntegerVertexGraphView.of(graph);
		
		System.out.println(graph);
		System.out.println(graph2);
		
		Integer origen = graph2.getIndex(ciudad(graph,"Sevilla"));
		Integer destino = graph2.getIndex(ciudad(graph,"Almeria"));
		
		FloydVertex2.graph = graph2;
		FloydVertex2.n = graph2.vertexSet().size();
		FloydVertex2 p = FloydVertex2.initial(origen,destino);
		
//		GraphPath<Integer,SimpleEdge<Integer>> gp = p.solution();
		String2.toConsole(FloydVertex2.n.toString());
//		String2.toConsole(p.solutionWeight().toString());
		GraphPath<Integer, SimpleEdge<Integer>> gp = p.solution();
		GraphTree2<FloydVertex2, FloydEdge2, Boolean, GraphWalk<Integer, SimpleEdge<Integer>>> t = p.graphTree();
		
		String2.toConsole(gp.getVertexList().stream().map(i->graph2.vertex(i)).toList().toString());
		String2.toConsole(t.string());
		SimpleDirectedGraph<Union<FloydVertex2,FloydEdge2>, DefaultEdge> g = p.datos().graph();
		
		Datos.toDotHypergraph(g, "ficheros/hiperGraph.gv", p);
		Datos.toDotAndOr(g, "ficheros/andOrGraph.gv", p);
	}

}
