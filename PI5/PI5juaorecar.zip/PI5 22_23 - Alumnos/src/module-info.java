/**
 * @author : completar con NOMBRE Y APELLIDOS 
 * GRUPO: completar con el grupo de practicas, por ejemplo IS-1A
 * FECHA: completar con la fecha en la que realiza la entrega en EV, por ejemplo 05/04/23
 */

module miUVUS_PI5 {
	requires transitive grafos;
	requires partecomun;
	requires org.jgrapht.core;

}