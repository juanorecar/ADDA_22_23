module curso22_23_pi2 {
	requires partecomun;
}