package ejercicio1;

public class Ejercicio1PLE {

}
