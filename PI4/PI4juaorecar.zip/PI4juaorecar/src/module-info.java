module pi4juaorecar {
	requires transitive grafos;
	requires transitive geneticos;
	
	exports datos;
	exports soluciones;
	exports ejercicio1;
	exports ejercicio2;
	exports ejercicio3;
}