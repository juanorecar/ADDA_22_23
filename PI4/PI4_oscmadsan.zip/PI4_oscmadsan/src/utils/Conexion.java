package utils;

public record Conexion(int id, Double dist) {
	
	public static int cont;
	
	public static Conexion of(Double dist) {
		Integer id = cont;
		cont++;
		return new Conexion(id, dist);
	}
	
	public static Conexion ofFormat(String[] forma) {
		Double distancia = Double.valueOf(forma[2].trim());
		return of(distancia);
	}

	@Override
	public String toString() {
		return "Conexion [id=" + id + ", dist=" + dist + "]";
	}
	
	

}
