module PI4_oscmadsan {
	requires transitive grafos;
	requires transitive geneticos;
	
	exports datos;
	exports solucion;
	exports ejercicio1;
	exports ejercicio2;
	exports ejercicio3;
}