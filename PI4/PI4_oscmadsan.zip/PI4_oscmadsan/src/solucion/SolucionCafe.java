package solucion;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import datos.DatosCafe;
import datos.DatosCafe.Variedad;

public class SolucionCafe {

	public static SolucionCafe of_Range(List<Integer> value) {
		return new SolucionCafe(value);
	}

	private Double beneficio;
	private List<Variedad> soluciones;
	private List<Integer> solucion;

	private SolucionCafe() {
		beneficio = 0.;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();
	}

	private SolucionCafe(List<Integer> ls) {
		beneficio = 0.;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();

		for (int i = 0; i < ls.size(); i++) {
			if (ls.get(i) > 0) {
				Integer kilos = ls.get(i);
				Integer benefvar = DatosCafe.getBenefVariedad(i) * kilos; // Benefvar = benef de cada variedad por la
																			// cantidad que hay
				soluciones.add(DatosCafe.getVariedades().get(i));
				solucion.add(ls.get(i));
				beneficio += benefvar; // Guardamos en beneficio los benefvar que se consiguen
			}
		}
	}

	public static SolucionCafe empty() {
		return new SolucionCafe();
	}

	// LE DAMOS FORMA AL SYSOUT:

	public String toString() {
		String str = soluciones.stream().map(v -> "P" + (v.id() + 1) + ": " + solucion.get(soluciones.indexOf(v)))
				.collect(Collectors.joining(" Kgs\n", "Variedades de cafe seleccionadas:\n", " Kg\n"));
		return String.format("%sBeneficio: %.1f", str, beneficio);
	}
}
