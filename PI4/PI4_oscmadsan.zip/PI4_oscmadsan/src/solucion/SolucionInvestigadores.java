package solucion;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import datos.DatosInvestigadores;
import datos.DatosInvestigadores.Investigador;

public class SolucionInvestigadores {

	public static SolucionInvestigadores of_Range(List<Integer> value) {
		return new SolucionInvestigadores(value);
	}

	private Integer calidad;
	private List<Investigador> investigadores;
	private List<List<Integer>> horas;

	private SolucionInvestigadores() {
		calidad = 0;
		investigadores = new ArrayList<>();
		horas = new ArrayList<>();
	}

	private SolucionInvestigadores(List<Integer> ls) {
		Integer nInvest = DatosInvestigadores.getNInvestigadores();
		Integer nTrabaj = DatosInvestigadores.getNTrabajos();
		Integer nEspec = DatosInvestigadores.getNEspecialidades();
		calidad = 0;
		investigadores = new ArrayList<>();
		investigadores.addAll(DatosInvestigadores.investigadores);
		horas = new ArrayList<>();

		for (int i = 0; i < nInvest; i++) {
			horas.add(new ArrayList<>());
		}
		for (int j = 0; j < nTrabaj; j++) {
			Integer jj = j * nInvest;
			List<Integer> trab = ls.subList(jj, jj + nInvest);
			for (int i = 0; i < nInvest; i++) {
				horas.get(i).add(trab.get(i));
			}
			Boolean realiza = true;
			for (int k = 0; k < nEspec; k++) {
				Integer suma = 0;
				for (int i = 0; i < nInvest; i++) {
					suma += trab.get(i) * DatosInvestigadores.trabajadorEspecialidad(i, k);
				}
				if (suma < DatosInvestigadores.diasNecesarios(j, k)) {
					realiza = false;
					k = nEspec;
				}
			}
			if (realiza) {
				calidad += DatosInvestigadores.getCalidad(j);
			}
		}
	}

	public static SolucionInvestigadores empty() {
		return new SolucionInvestigadores();
	}

	public String toString() {
		String str = investigadores.stream().map(i -> "INV" + (i.id() + 1) + ": " + horas.get(i.id()))
				.collect(Collectors.joining("\n",
						"Reparto obtenido (dias trabajados por cada investigador en cada trabajo):\n", "\n"));
		return String.format("%sSUMA DE LAS CALIDADES DE LOS TRABAJOS REALIZADOS: %d", str, calidad);
	}

}
