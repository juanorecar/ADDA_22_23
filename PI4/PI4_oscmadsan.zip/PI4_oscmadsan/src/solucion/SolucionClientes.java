package solucion;

import java.util.ArrayList;
import java.util.List;

import datos.DatosClientes;
import utils.Cliente;

public class SolucionClientes {
	
	public static SolucionClientes of_Rnage(List<Integer> value) {
		return new SolucionClientes(value);
	}
	
	private Double kms;
	private Double benef;
	private List<Cliente> clientes;

	private SolucionClientes() {
		kms = 0.;
		benef = 0.;
		clientes = new ArrayList<>();
		Cliente client0 = DatosClientes.getCliente(0);
		clientes.add(client0);
	}
	
	private SolucionClientes(List<Integer> value) {
		kms = 0.;
		benef = 0.;
		clientes = new ArrayList<>();
		Cliente client0 = DatosClientes.getCliente(0);
		clientes.add(client0);
		
		for (int i=0; i<value.size(); i++) {
			Cliente client = DatosClientes.getCliente(value.get(i));
			clientes.add(client);
			
			if (i == 0) {
				if(DatosClientes.existeArista(0, value.get(i))) {
					kms += DatosClientes.getPeso(0, value.get(i));
					benef += DatosClientes.getBenef(value.get(i)) - kms;
				}
			} else {
				if(DatosClientes.existeArista(value.get(i - 1), value.get(i))) {
					kms += DatosClientes.getPeso(value.get(i - 1), value.get(i));
					benef += DatosClientes.getBenef(value.get(i)) - kms;
				}
			}
		}
	}
	
	public static SolucionClientes empty() {
		return new SolucionClientes();
	}
	
	public String toString() {
		List<Integer> ids = clientes.stream().map(client -> client.id()).toList();
		return "Camino desde 0 hasta 0:\n" + ids + "\nKms: " + kms + "\nBeneficio: " + benef;
	}
	
}
