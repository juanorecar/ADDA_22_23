package ejercicio1;

import java.util.List;

import datos.DatosCafe;
import solucion.SolucionCafe;
import us.lsi.ag.ValuesInRangeData;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;

public class InRangeCafeAG implements ValuesInRangeData<Integer, SolucionCafe> {

	public InRangeCafeAG(String fich) {
		DatosCafe.iniDatos(fich);
	}

	@Override
	public Integer max(Integer i) {
		return DatosCafe.getMaxCantidadVariedad(i) + 1;
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

	@Override
	public Integer size() {
		return DatosCafe.getNumVariedades();
	}

	@Override
	public ChromosomeType type() {
		return ChromosomeType.Range;
	}

	@Override
	public Double fitnessFunction(List<Integer> ls_chrm) {
		double goal = 0, error = 0, dif = 0, k = 0;
		for (int i = 0; i < size(); i++) {
			if (ls_chrm.get(i) > 0) {
				goal += ls_chrm.get(i) * DatosCafe.getBenefVariedad(i); // GOAL DEL PROBLEMA, BENEF DE VARIEDAD * LA VARIEDAD
			}
		}
		for (int j = 0; j < DatosCafe.getNumTipos(); j++) {
			dif = 0;
			for (int i = 0; i < size(); i++) { // RESTRICCION: DEBEMOS TENER CANTIDAD DISPONIBLE DE CADA TIPO
				dif += ls_chrm.get(i) * DatosCafe.getCantidadTipoVariedad(j, i); 
			}
			if (dif > DatosCafe.getCantidadTipo(j)) {
				error += dif - DatosCafe.getCantidadTipo(j);
			}
		}
		for (int i = 0; i < size(); i++) { // CALCULO DE K (A CONTINUACION LO MULTIPLICAMOS POR EL ERROR PARA QUE ESTE SEA GRANDE) 
			k += Math.pow(DatosCafe.getMaxCantidadVariedad(i) * DatosCafe.getBenefVariedad(i), 2);
		}
		return goal - k * error;
	}

	@Override
	public SolucionCafe solucion(List<Integer> ls_chrm) {
		return SolucionCafe.of_Range(ls_chrm);
	}

}
