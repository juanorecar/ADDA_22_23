package ejercicio1;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import datos.DatosCafe;
import datos.DatosCafe.Variedad;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class Ejercicio1PLE {
	
	public static List<Integer> tipos;
	public static List<Variedad> variedades;

	
	public static Integer getNumTipos() {
		return tipos.size();
	}
	
	public static Integer getNumVariedades() {
		return variedades.size();
	}
	
	public static Integer getCantidadTipo(Integer j) {
		return tipos.get(j);
	}
	
	public static Integer getBenefVariedad(Integer i) {
		return variedades.get(i).beneficio();
	}
	
	public static Double getCantidadTipoVariedad(Integer j, Integer i) {
		return variedades.get(i).composicion().get(j);
	}

	
	public static void ejercicio1_model() throws IOException {
		for(int i = 1; i < 4; i++) {
			System.out.println("\n\n#####################################################################################");
			System.out.println("FICHERO EJERCICIO 1 CON DATOS DE ENTRADA " + i);
			System.out.println("#####################################################################################\n");
			
			DatosCafe.iniDatos("ficheros/Ejercicio1DatosEntrada" + i + ".txt");
			
			tipos = DatosCafe.tipos;
			variedades = DatosCafe.variedades;
			
			AuxGrammar.generate(Ejercicio1PLE.class, "lsi_models/Ejercicio1.lsi", "gurobi_models/Ejercicio1-" + i + ".lp");
			GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio1-" + i + ".lp");
			Locale.setDefault(new Locale("en", "US"));
			System.out.println(solution.toString((s, d) -> d > 0.));
		}
	}

	public static void main(String[] args) throws IOException {
		ejercicio1_model();
	}

}
