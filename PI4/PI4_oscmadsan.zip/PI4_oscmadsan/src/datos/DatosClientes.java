package datos;

import java.util.ArrayList;
import java.util.List;

import org.jgrapht.Graph;

import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;
import utils.Cliente;
import utils.Conexion;

public class DatosClientes {
	
	@SuppressWarnings("exports") // PARA SUPRIMIR EL AVISO Y PERMITIR EXPORTACION SIN TENER QUE PONERLO EN EL MODULE INFO
	public static Graph<Cliente, Conexion> graf;
	
	public static void iniDatos(String fich) {
		graf = GraphsReader.newGraph(fich, Cliente::ofFormat, Conexion::ofFormat, Graphs2::simpleWeightedGraph);
		toConsole();
	}
	
	public static Integer getNVertices() {
		return graf.vertexSet().size();
	}
	
	@SuppressWarnings("exports")
	public static Cliente getCliente(Integer i) {
		Cliente client = null;
		List<Cliente> vs = new ArrayList<>(graf.vertexSet());
		for (int k = 0; k < vs.size(); k++) {
			if (vs.get(k).id() == i) {
				client = vs.get(k);
			}
		}
		return client;
	}
	
	public static Double getBenef(Integer i) {
		Cliente client = getCliente(i);
		return client.beneficio();
	}
	
	public static Double getPeso(Integer i, Integer j) {
		Cliente client1 = getCliente(i);
		Cliente client2 =  getCliente(j);
		return graf.getEdge(client1, client2).dist();
	}
	
	public static Boolean existeArista(Integer i, Integer j) {
		Cliente client1 = getCliente(i);
		Cliente client2 =  getCliente(j);
		return graf.containsEdge(client1, client2);
	}
	
	public static void toConsole() {
		System.out.println("Numero de vertices: " + graf.vertexSet().size() + "\n\tVertices: " + graf.vertexSet()
		+ "\nNumero de aristas: " + graf.edgeSet().size() + "\n\tAristas: " + graf.edgeSet());
	}

	public static void main(String[] args) {
		for (int i = 1; i < 3; i++) {
			System.out.println("\n######################## DATOS FICHERO " + i + " ########################\n");
			String fich = "ficheros/Ejercicio4DatosEntrada" + i + ".txt";
			iniDatos(fich);
			System.out.println("\n");
		}
	}

}
