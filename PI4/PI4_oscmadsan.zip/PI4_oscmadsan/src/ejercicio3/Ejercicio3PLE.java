package ejercicio3;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import datos.DatosInvestigadores;
import datos.DatosInvestigadores.Investigador;
import datos.DatosInvestigadores.Trabajo;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class Ejercicio3PLE {
	
	public static List<Investigador> investigadores;
	public static List<Trabajo> trabajos;
	
	public static Integer getNInvestigadores() {
		return investigadores.size();
	}
	
	public static Integer getNEspecialidades() {
		return trabajos.get(0).dias().size();
	}
	
	public static Integer getNTrabajos() {
		return trabajos.size();
	}
	
	public static Integer trabajadorEspecialidad(Integer i, Integer k) {
		return investigadores.get(i).especialidad().equals(k) ? 1 : 0;
				}
	
	public static Integer diasDisponibles(Integer i) {
		return investigadores.get(i).capacidad();
	}
	
	public static Integer diasNecesarios(Integer j, Integer k) {
		return trabajos.get(j).dias().get(k);
	}
	
	public static Integer getCalidad(Integer j) {
		return trabajos.get(j).calidad();
	}
	
	public static Integer getMM() {
		return investigadores.stream().map(i -> i.capacidad()).max(Comparator.naturalOrder()).get() + 1;
	}

	public static void ejercicio3_model() throws IOException {
		for(int i = 1; i < 4; i++) {
			System.out.println("\n\n#####################################################################################");
			System.out.println("FICHERO EJERCICIO 3 CON DATOS DE ENTRADA " + i);
			System.out.println("#####################################################################################\n");
			
			DatosInvestigadores.iniDatos("ficheros/Ejercicio3DatosEntrada" + i + ".txt");
			
			investigadores = DatosInvestigadores.investigadores;
			trabajos = DatosInvestigadores.trabajos;
			
			AuxGrammar.generate(Ejercicio3PLE.class, "lsi_models/Ejercicio3.lsi", "gurobi_models/Ejercicio3-" + i + ".lp");
			GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio3-" + i + ".lp");
			Locale.setDefault(new Locale("en", "US"));
			System.out.println(solution.toString((s, d) -> d > 0.));
		}
	}

	public static void main(String[] args) throws IOException {
		ejercicio3_model();
	}

}
