package ejercicio3;

import java.io.IOException;
import java.util.Locale;
import _datos.DatosEjercicio3;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class Ejercicio3PLE {
	
	public static Integer getNumeroInvestigadores() {
		return DatosEjercicio3.getNumeroInvestigadores();
	}
	
	public static Integer getNumeroEspecialidades() {
		return DatosEjercicio3.getNumeroEspecialidades();
	}
	
	public static Integer getNumeroTrabajos() {
		return DatosEjercicio3.getNumeroTrabajos();
	}
	
	public static Integer getTrabajadorEspecialidad(Integer i, Integer k) {
		return DatosEjercicio3.getTrabajadorEspecialidad(i, k);		
	}
	
	public static Integer getDiasDisponibles(Integer i) {
		return DatosEjercicio3.getDiasDisponibles(i);
	}
	
	public static Integer getDiasNecesariosParaTrabajo(Integer j, Integer k) {
		return DatosEjercicio3.getDiasNecesariosParaTrabajo(j, k);
	}
	
	public static Integer getCalidadTrabajo(Integer j) {
		return DatosEjercicio3.getCalidadTrabajo(j);
	}
	
	public static Integer getC() {
		return DatosEjercicio3.getC();
	}
	
	
	
	
public static void ejercicio3_model() throws IOException {
		
		for(int i = 1; i <= 3; i++) {
			DatosEjercicio3.iniDatos("ficheros/Ejercicio3DatosEntrada" + i +".txt");
			
			AuxGrammar.generate(Ejercicio3PLE.class,"lsi_models/Ejercicio3.lsi","gurobi_models/Ejercicio3-" + i + ".lp");
			GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio3-" + i + ".lp");
			Locale.setDefault(new Locale("en", "US"));
			System.out.println(solution.toString((s,d)->d>0.));
		}
		
		
	}

	public static void main(String[] args) throws IOException {
		
		ejercicio3_model();

	}
}
