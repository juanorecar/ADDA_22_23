package ejercicio3;

import java.util.List;

import _datos.DatosEjercicio1;
import _datos.DatosEjercicio3;
import _soluciones.SolucionEjercicio1;
import _soluciones.SolucionEjercicio3;
import us.lsi.ag.ValuesInRangeData;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;
import us.lsi.common.List2;


public class InRangeEjercicio3AG implements ValuesInRangeData<Integer, SolucionEjercicio3>{
	
	public InRangeEjercicio3AG(String fichero) {
		DatosEjercicio3.iniDatos(fichero);
	}

	@Override
	public Integer size() {
		return DatosEjercicio3.getNumeroInvestigadores()*DatosEjercicio3.getNumeroTrabajos();
	}

	@Override
	public ChromosomeType type() {
		return ChromosomeType.Range;
	}

	@Override
	public Double fitnessFunction(List<Integer> ls) {
		double goal = 0;
		double error = 0;
		double mult = 0;
		int capacidad = 0;
		
		Integer numeroInv = DatosEjercicio3.getNumeroInvestigadores();
		Integer numeroEspe = DatosEjercicio3.getNumeroEspecialidades();
		Integer numeroTrab = DatosEjercicio3.getNumeroTrabajos();
		
		List<Integer> capacidades = List2.ofTam(0, numeroInv);
		
		
		for(int i = 0; i < ls.size(); i++) {
			Integer iInv = i * numeroInv;
			List<Integer> trabajos = ls.subList(iInv, iInv+numeroInv);
			Boolean se_realiza = true;
			for(int j = 0; j < numeroEspe; j++) {
				Integer sum_dias = 0;
				for(int k = 0; k < numeroInv; k++) {
					sum_dias += trabajos.get(i)*DatosEjercicio3.getTrabajadorEspecialidad(k, j);
				}
				
				if(sum_dias < DatosEjercicio3.getDiasNecesariosParaTrabajo(i, j)) {
					se_realiza = false;
					error += Math.abs(sum_dias - DatosEjercicio3.getDiasNecesariosParaTrabajo(i, j));
				}
			}
			
			if(se_realiza) {
				goal += DatosEjercicio3.getCalidadTrabajo(i);
			}
			
			for(int j = 0; j <numeroInv; j++) {
				capacidad = 0;
				for(int k1 = 0; k1 < ls.size(); k1++) {
					capacidad = ls.get(k1);
					capacidades.set(i, capacidades.get(i)+capacidad);
				}
			}
		}
		
		
		//que los grupos tengan t alumnos
		for(int j=0; j<capacidades.size(); j++) {
			if(capacidades.get(j)>DatosEjercicio3.getDiasDisponibles(j)) {
				error += capacidad-DatosEjercicio3.getDiasDisponibles(j);
			}
		}
		Integer cont = 0;
		for(int i = 0; i < numeroTrab; i++) {
			cont += DatosEjercicio3.getCalidadTrabajo(i);
		}
		
		mult = Math.pow(cont, 2);
		
		return goal -cont*error;
	}

	@Override
	public SolucionEjercicio3 solucion(List<Integer> ls) {
		return SolucionEjercicio3.of(ls);
	}

	@Override
	public Integer max(Integer i) {
		Integer investigadores = i%DatosEjercicio3.getNumeroInvestigadores();
		return DatosEjercicio3.getDiasDisponibles(investigadores)+1;
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

}
