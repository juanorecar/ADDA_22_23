package _soluciones;

import java.util.ArrayList;
import java.util.List;

import _datos.DatosEjercicio1;
import _datos.DatosEjercicio1.Variedad;

public class SolucionEjercicio1 {
	public static SolucionEjercicio1 of(List<Integer> ls) {
		return new SolucionEjercicio1(ls);
	}
	
	
	private Double beneficio;
	private List<Variedad> soluciones;
	private List<Integer> solucion;
	
	public SolucionEjercicio1() {
		beneficio = 0.;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();
	}
	
	public SolucionEjercicio1(List<Integer> ls) {
		beneficio = 0.;
		soluciones = new ArrayList<>();
		solucion = new ArrayList<>();
		for(int i=0; i<ls.size(); i++) {
			if(ls.get(i)>0) {
				Integer kg = ls.get(i);
				Integer benef = DatosEjercicio1.getBeneficio(i)*kg;
				soluciones.add(DatosEjercicio1.variedades.get(i));
				solucion.add(ls.get(i));
				beneficio += benef;
			}
		}
	}
	
	public static SolucionEjercicio1 empty() {
		return new SolucionEjercicio1();
	}
	
	
	public String toString() {
		return "SolucionEjercicio1 [beneficio=" + beneficio + ", soluciones=" + soluciones + ", solucion=" + solucion
				+ "]";
	}
	
}
