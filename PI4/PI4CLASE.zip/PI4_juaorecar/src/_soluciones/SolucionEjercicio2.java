package _soluciones;

import java.util.ArrayList;
import java.util.List;

import _datos.DatosEjercicio2;
import _datos.DatosEjercicio2.Curso;
import us.lsi.common.List2;

public class SolucionEjercicio2 {
	
	public static SolucionEjercicio2 of(List<Integer> value) {
		return new SolucionEjercicio2(value);
	}
	
	private Double precio;
	private List<Curso> cursos;
	
	public SolucionEjercicio2() {
		precio = 0.;
		cursos = new ArrayList<>();
	}
	public SolucionEjercicio2(List<Integer> ls) {
		precio = 0.;
		cursos = List2.empty();
		for(int i=0; i<ls.size(); i++) {
			if(ls.get(i)>0) {
			precio+=DatosEjercicio2.getPrecioInscripcion(i);
			cursos.add(DatosEjercicio2.cursos.get(i));
			}
		}
	}
	public static SolucionEjercicio2 empty() {
		return new SolucionEjercicio2();
	}
	@Override
	public String toString() {
		return "SolucionEjercicio2 [precio=" + precio + ", cursos=" + cursos + "]";
	}
	
	
	
	
}
