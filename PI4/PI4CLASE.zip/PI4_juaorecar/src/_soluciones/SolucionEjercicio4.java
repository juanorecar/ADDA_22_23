package _soluciones;

import java.util.ArrayList;
import java.util.List;

import _datos.DatosEjercicio4;
import _datos.DatosEjercicio4.Cliente;

public class SolucionEjercicio4 {
	
	public static SolucionEjercicio4 of(List<Integer> ls) {
		return new SolucionEjercicio4();
	}
	
	private Double kms;
	private Double beneficio;
	private List<Cliente> clientes;
	private SolucionEjercicio4() {
		kms = 0.;
		beneficio = 0.;
		clientes = new ArrayList<>();
		Cliente inicio = DatosEjercicio4.getCliente(0);
		clientes.add(inicio);
	}
	
	private SolucionEjercicio4(List<Integer> ls) {
		kms = 0.;
		beneficio = 0.;
		clientes = new ArrayList<>();
		Cliente inicio = DatosEjercicio4.getCliente(0);
		clientes.add(inicio);
		for(int i = 0; i < ls.size(); i++) {
			Cliente cliente = DatosEjercicio4.getCliente(ls.get(i));
			clientes.add(cliente);
			if(i==0) {
				if(DatosEjercicio4.existeCamino(0, ls.get(i))) {
					kms += DatosEjercicio4.getKm(0, ls.get(i));
					beneficio += DatosEjercicio4.getBeneficio(ls.get(i)) - kms;
				}
			}else {
				if(DatosEjercicio4.existeCamino(ls.get(i-1), ls.get(i))) {
					kms+=DatosEjercicio4.getKm(ls.get(i-1), ls.get(i));
					beneficio += DatosEjercicio4.getBeneficio(ls.get(i));
				}
			}
		}
	}
	
	public static SolucionEjercicio4 empty() {
		return new SolucionEjercicio4();
	}

	@Override
	public String toString() {
		return "SolucionEjercicio4 [kms=" + kms + ", beneficio=" + beneficio + ", clientes=" + clientes + "]";
	}
	
	
	
}
