package _soluciones;

import java.util.ArrayList;
import java.util.List;
import _datos.DatosEjercicio3;
import _datos.DatosEjercicio3.Investigador;

public class SolucionEjercicio3 {
	
	public static SolucionEjercicio3 of(List<Integer> value) {
		return new SolucionEjercicio3(value);
	}
	
	private Integer calidad;
	private List<Investigador> investigadores;
	private List<List<Integer>> horas;
	
	public SolucionEjercicio3() {
		calidad = 0;
		investigadores = new ArrayList<>();
		horas = new ArrayList<>();
	}
	
	public SolucionEjercicio3(List<Integer> ls) {
		Integer numeroInv = DatosEjercicio3.getNumeroInvestigadores();
		Integer numeroTrab = DatosEjercicio3.getNumeroTrabajos();
		Integer numeroEspe = DatosEjercicio3.getNumeroEspecialidades();
		calidad = 0;
		investigadores = new ArrayList<>();
		investigadores.addAll(DatosEjercicio3.investigadores);
		horas = new ArrayList<>();
		for(int i=0; i<numeroInv; i++) {
			horas.add(new ArrayList<>());
		}
		for(int j = 0; j < numeroTrab; j++) {
			Integer it = j * numeroInv;
			List<Integer> trabajo = ls.subList(it, it+numeroInv);
			
			for(int i = 0; i < numeroInv; i++) {
				horas.get(i).add(trabajo.get(i));
			}
			
			Boolean se_realiza = true;
			
			for (int k = 0; k < numeroEspe; k++) {
				Integer suma = 0;
				for(int i = 0; i < numeroInv; i++) {
					suma+= trabajo.get(i) * DatosEjercicio3.getTrabajadorEspecialidad(i, k);
				}
				if(suma<DatosEjercicio3.getDiasNecesariosParaTrabajo(j, k)) {
					se_realiza = false;
					k = numeroEspe;
				}
			}
			
			if(se_realiza) {
				calidad += DatosEjercicio3.getCalidadTrabajo(j);
			}
		}
	}
	public static SolucionEjercicio3 empty() {
		return new SolucionEjercicio3();
	}

	@Override
	public String toString() {
		return "SolucionEjercicio3 [calidad=" + calidad + ", investigadores=" + investigadores + ", horas=" + horas
				+ "]";
	}	
	
}
