package _soluciones;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import _datos.DatosEjercicioCafes;
import _datos.DatosEjercicioCafes.Variedad;
import us.lsi.common.List2;

public class SolucionCafes {
	
	
	public static SolucionCafes of(List<Integer> ls) {
		return new SolucionCafes(ls);
	}

	private Integer beneficio;
	private Map<Variedad, Double> mezclas;
	private Integer peso;
	private List<Integer> listaPesos;
	
	private SolucionCafes() {
		beneficio = 0;
		mezclas = new HashMap<>();
		peso = 0;
	}
	
	private SolucionCafes(List<Integer> list) {
		beneficio = 0;
		peso = 0;
		mezclas = new HashMap<>();
		listaPesos = List2.ofTam(0, list.size());
		for(int j = 0; j < list.size(); j++) {
			if(list.get(j)>0) {
				Integer valor = list.get(j);
				Variedad variedad = DatosEjercicioCafes.getListaVariedades().get(j);
				
				peso = valor;
				listaPesos.set(j, peso);
				mezclas.put(variedad, valor.doubleValue());
				
				beneficio += variedad.beneficio() * valor;
			}
		}
	}

	@Override
	public String toString() {
		return "SolucionCafes [beneficio=" + beneficio + ", mezclas=" + mezclas + ", peso=" + peso + ", listaPesos="
				+ listaPesos + "]";
	}
	
	
	
	
}
