package ejercicio4;

import java.util.List;

import _datos.DatosEjercicio4;
import _datos.DatosEjercicioCafes;
import _soluciones.SolucionEjercicio4;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;

public class PermEjercicio4AG {

	
	public PermEjercicio4AG(String fichero) {
		DatosEjercicio4.iniDatos(fichero);
	}
	

	public ChromosomeType type() {
		return ChromosomeType.Permutation;
	}
	
	public Double fitnessFunction(List<Integer> value) {
		
		Double goal = 0.;
		Double error = 0.;
		Double multiplicando = 0.;
		Double kms = 0.;
		
		
		for(int i = 0; i < value.size(); i++) {
			if(i==0) {
				if(DatosEjercicio4.existeCamino(0, value.get(i))) {
					kms += DatosEjercicio4.getKm(0, value.get(i));
					goal += DatosEjercicio4.getBeneficio(value.get(i)) - kms;
				}else {
					error++;
				}
			}else {
				if(DatosEjercicio4.existeCamino(value.get(i-1), value.get(i))) {
					kms += DatosEjercicio4.getKm(value.get(i-1), value.get(i));
					goal += DatosEjercicio4.getBeneficio(value.get(i));
				}else {
					error++;
				}
			}
		}
		
		if(value.get(value.size()-1) != 0) {
			if(error == 0) {
				error += 2;
			}else {
				error = error * 2;
			}
		}
		
		multiplicando = Math.pow(kms, 2);
		return goal - multiplicando * error;
		
	}
	
	public SolucionEjercicio4 solucion(List<Integer> value) {
		return SolucionEjercicio4.of(value);
	}
	
	public Integer itemsNumber() {
		return DatosEjercicio4.getNumeroClientes();
	}
	
}
