package ejercicio2;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import _datos.DatosEjercicio2;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class Ejercicio2PLE {
	
	public static List<Integer> getTematicas(){
		return DatosEjercicio2.getTematicas();
	}
	
	public static Integer getNumeroCursos() {
		return DatosEjercicio2.getNumeroCursos();
	}
	
	public static Integer getNumeroTematicas() {
		return DatosEjercicio2.getNumeroTematicas();
	}
	
	public static Integer getNumeroCentros() {
		
		return DatosEjercicio2.getNumeroCentros();
	}
	
	public static Integer getMaxCentros() {
		return DatosEjercicio2.getMaxCentros();
	}
	
	public static List<Integer> getTematicasCurso(Integer i){
		return DatosEjercicio2.getTematicasCurso(i);
	}
	
	public static Integer getNumTematicasCurso(Integer i) {
		return DatosEjercicio2.getNumTematicasCurso(i);
	}
	
	public static Integer getTematicaEnCurso(Integer i, Integer j) {
		return DatosEjercicio2.getTematicaEnCurso(i, j);
	}
	
	public static Double getPrecioInscripcion(Integer i) {
		return DatosEjercicio2.getPrecioInscripcion(i);
	}
	
	public static Integer getCentroCurso(Integer i) {
		return DatosEjercicio2.getCentroCurso(i);
	}
	
	public static List<Integer> getCentros(){
		return DatosEjercicio2.getCentros();
	}
	
	public static Integer getNumCentros() {
		return DatosEjercicio2.getNumCentros();
	}
	
	public static Integer getCursoEnCentro(Integer i, Integer k) {
		return DatosEjercicio2.getCursoEnCentro(i, k);
	}
	
	
public static void ejercicio2_model() throws IOException {
		
		for(int i = 1; i <= 3; i++) {
			DatosEjercicio2.iniDatos("ficheros/Ejercicio2DatosEntrada" + i +".txt");
			
			AuxGrammar.generate(Ejercicio2PLE.class,"lsi_models/Ejercicio2.lsi","gurobi_models/Ejercicio2-" + i + ".lp");
			GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio2-" + i + ".lp");
			Locale.setDefault(new Locale("en", "US"));
			System.out.println(solution.toString((s,d)->d>0.));
		}
		
		
	}

	public static void main(String[] args) throws IOException {
		
		ejercicio2_model();

	}
}
