package ejercicio2;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import _datos.DatosEjercicio2;
import _soluciones.SolucionEjercicio2;
import us.lsi.ag.BinaryData;

public class BinEjercicio2AG implements BinaryData<SolucionEjercicio2>{
	
	public BinEjercicio2AG(String fichero) {
		DatosEjercicio2.iniDatos(fichero);
	}

	@Override
	public Integer size() {
		return DatosEjercicio2.getNumeroCursos();
	}

	@Override
	public Double fitnessFunction(List<Integer> value) {
		double goal = 0, k = 0, suma = 0, error = 0;
		Set<Integer> te = new HashSet<Integer>();
		Set<Integer> ce = new HashSet<Integer>();
		
		for(int i = 0; i < value.size(); i++) {
			if(value.get(i) > 0) {
				goal += DatosEjercicio2.getPrecioInscripcion(i);
			}
		}
		for(int i = 0; i<value.size(); i++) {
			if(value.get(i)>0) {
				te.addAll(DatosEjercicio2.getTematicasCurso(i));
				ce.add(DatosEjercicio2.getMaxCentros());
			}
		}
		Integer m = DatosEjercicio2.getNumeroTematicas();
		Integer nc = DatosEjercicio2.getMaxCentros();
		
		if(te.size()<m) {
			error += m-te.size();
		}
		
		if(ce.size()>nc) {
			error += ce.size()-nc;
		}
		
		for(int i=0; i<value.size();i++) {
			suma += DatosEjercicio2.getPrecioInscripcion(i);
		}
		k += Math.pow(suma, 2);
		
		return -goal -k*error;
	}

	@Override
	public SolucionEjercicio2 solucion(List<Integer> value) {
		return SolucionEjercicio2.of(value);
	}

}
