package _datos;

import java.util.ArrayList;
import java.util.List;

import org.jgrapht.Graph;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class DatosEjercicio4 {
	
	public static record Cliente(Integer id, Double beneficio) {
		public static Cliente ofFormat(String[] v) {
			return new Cliente(Integer.parseInt(v[0].trim()), Double.parseDouble(v[1].trim()));
			
		}
	}
	
	public static record Trayecto(Integer origen, Integer destino, Double kilometros) {
		public static Trayecto ofFormat(String[] v) {
			return new Trayecto(Integer.parseInt(v[0]),Integer.parseInt(v[1]), Double.parseDouble(v[2]));
		}
	}
	
	public static Graph<Cliente, Trayecto> grafo;
	
	public static void iniDatos(String fichero) {
		grafo = GraphsReader.newGraph(fichero, Cliente::ofFormat, Trayecto::ofFormat, Graphs2::simpleWeightedGraph);
		toConsole();
	}
	
	public static Integer getNumeroClientes() {
		return grafo.vertexSet().size();
	}
	
	public static Cliente getCliente(Integer i) {
		Cliente c = null;;
		List<Cliente> v = new ArrayList<>(grafo.vertexSet());
		for(int j = 0; j < v.size(); j++) {
			if(v.get(j).id()==i) {
				c = v.get(j);
			}
		}
		return c;
	}
	
	public static Double getBeneficio(Integer i) {
		return getCliente(i).beneficio();
	}
	
	public static Boolean existeCamino(Integer i, Integer j) {
		return grafo.containsEdge(getCliente(i), getCliente(j));
	}
	
	public static Double getKm(Integer i, Integer j) {
		return grafo.getEdge(getCliente(i), getCliente(j)).kilometros();
	}
	
	private static void toConsole() {
		System.out.println("Vertices: " + grafo.vertexSet() + "\nAristas: " + grafo.edgeSet());
	}
	
}