package _datos;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import us.lsi.common.Files2;

public class DatosEjercicio1 {
	

	public static record Tipo(String id, Integer kgdisponibles) {
		
		public static Tipo of(String s) {
			String[] trozos = s.split(";");
			String id = trozos[0].split(":")[0].trim();
			Integer kgdisponibles = Integer.valueOf(trozos[0].split(": kgdisponibles=")[1]);
			
			return new Tipo(id, kgdisponibles);
		}
		@Override
		public String toString() {
			return String.format("%s{prod=%d}",id, kgdisponibles);
		}
		
	}

	public record Variedad(String id, Integer beneficio, Map<String, Double> comp) {
		
		public static Variedad of(String s) {
			String[] trozos1 = s.split("->");
			String[] trozos2 = trozos1[1].split(";");

			String id = trozos1[0].trim();
			Integer beneficio = Integer.valueOf(trozos2[0].split("beneficio=")[1].trim());
			

			Map<String, Double> comp = tipos.stream()
					.collect(Collectors.toMap(k -> k.id, v -> 0.));
			List<String> cs = List.of(trozos2[1].split("comp=")[1].split(","));
			for(String c : cs) {
				comp.put(c.split(":")[0].replace("(", ""), 
						Double.valueOf(c.split(":")[1].replace(")", "")));
			}

			return new Variedad(id, beneficio, comp);
		}
		
		public Double porcentaje(Integer k) {
			String key = String.format("C%02d", k);
			return comp.get(key);
		}
	}
	
	public static List<Tipo> tipos;
	public static List<Variedad> variedades;
		
	public static void iniDatos(String ruta) {
		
		tipos = new ArrayList<>();
		variedades = new ArrayList<>();
			
		List<String> datos = Files2.linesFromFile(ruta);
		Iterator<String> it = datos.iterator();
		while(it.hasNext()) {
			String linea = it.next();
			if(linea.charAt(0) == 'C') {
				tipos.add(Tipo.of(linea));
			}else if(linea.charAt(0) == 'P'){
				variedades.add(Variedad.of(linea));
			}
		}
	}
	
	public static Integer getTipos() {
		return tipos.size();
	}
	public static Integer getVariedades() {
		return variedades.size();
	}
	public static Integer getCantidadDisponible(Integer j) {
		return tipos.get(j).kgdisponibles();
	}
	public static Integer getBeneficio(Integer i) {
		return variedades.get(i).beneficio();
	}
	public static Double getPorcentaje(Integer i, Integer j) {
		return variedades.get(i).porcentaje(j);
	}
	
	public static void main(String[] args) {
		DatosEjercicio1.iniDatos("ficheros/Ejercicio1DatosEntrada1.txt");
		System.out.println(tipos);
		System.out.println(variedades);
	}
}
