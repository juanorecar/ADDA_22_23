package _datos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import us.lsi.common.Files2;

public class DatosEjercicioInvestigadores {

	public static record Investigador(String id, Integer capacidad, Integer especialidad) {
		public static Investigador of(String id, Integer capacidad, Integer especialidad) {
			return new Investigador(id, capacidad, especialidad);
		}
	}
	
	public static record Variedad(String id, Integer beneficio, Map<String, Double> porcentajes) {
		public static Variedad of(String id, Integer beneficio, Map<String, Double> porcentajes) {
			return new Variedad(id, beneficio, porcentajes);
		}
	}
	
	public static List<Tipo> tipos;
	private static List<Variedad> variedades;
	
	
	public static void iniDatos(String fichero) {
		List<String> datos = Files2.linesFromFile(fichero);
		
		List<Tipo> tiposCafe = new ArrayList<>();
		List<Variedad> variedadesCafe = new ArrayList<>();
		List<Map<String, Double>> listaPorcentajes = new ArrayList<>();
		
		for(String linea : datos) {
			if(linea.startsWith("C")) {
				String[] v = linea.split(":");
				String tipo = v[0];
				String[] kilos = v[1].split("=");
				Integer kilogramosDisponibles = Integer.parseInt(kilos[1].substring(0, kilos[1].length()-1));
				Tipo t = Tipo.of(tipo, kilogramosDisponibles);
				tiposCafe.add(t);
				
			}else if(linea.startsWith("P")) {
				
				String[] v = linea.split(" -> ");
				String variedad = v[0];
				
				String[] partes = v[1].split(";");
				String[] b = partes[0].split("=");
				Integer beneficio = Integer.parseInt(b[1]);
				
				String[] reparto = partes[1].split("=");
				String r = reparto[1].substring(0, reparto[1].length());
				String[] p = r.split(",");
				Map<String, Double> map = new HashMap<>();
				for(String relacion : p) {
					String[] rela = relacion.split(":");
					String tipo = rela[0].substring(1, rela[1].length());
					
					Double consumo = Double.parseDouble(rela[1].substring(0, rela[1].length()-1));
					map.put(tipo, consumo);
				}
				Variedad variety = Variedad.of(variedad, beneficio, map);
				variedadesCafe.add(variety);
				listaPorcentajes.add(map);
			}
		}
		tipos = tiposCafe;
		variedades = variedadesCafe;
	}
}
