package _datos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import us.lsi.common.Files2;

public class DatosEjercicio2 {

	
public static record Curso(List<Integer> tematicas, Double precio, Integer centro) {
		
		public static Curso of(String s) {
			String[] trozos = s.split(":");
			List<Integer> centros = new ArrayList<>();
			Double precio = Double.parseDouble(trozos[1].trim());
			Integer imparte = Integer.parseInt(trozos[2].trim());
			String[] t = trozos[0].substring(1, trozos[0].length()-1).split(",");
			for(String sr:t) {
				centros.add(Integer.parseInt(sr.trim()));
			}
			
			return new Curso(new ArrayList<>(centros), precio, imparte);
		}
		@Override
		public String toString() {
			return String.format("%s{precio=%.1f, centro=%d}",tematicas, precio, centro);
		}
		
	}
	
	
	public static Integer maxCentros;
	public static List<Curso> cursos = new ArrayList<Curso>();
	
	public static void iniDatos(String ruta) {
		List<String> datos = Files2.linesFromFile(ruta);
		
		maxCentros = Integer.parseInt(datos.get(0).split("=")[1].trim());
		
		for(String r : datos.subList(1, datos.size())) {
			cursos.add(Curso.of(r));
		}
		
	  }
	
	public static List<Integer> getTematicas(){
		Set<Integer> res = new HashSet<>();
		for(Curso c : cursos) {
			res.addAll(c.tematicas());
		}
		return new ArrayList<>(res);
	}
	
	public static Integer getNumeroCursos() {
		return cursos.size();
	}
	
	public static Integer getNumeroTematicas() {
		return getTematicas().size();
	}
	
	public static Integer getNumeroCentros() {
		Set<Integer> centros = new HashSet<>();
		for(int i = 0; i<cursos.size(); i++) {
			centros.add(cursos.get(i).centro());
		}
		return centros.size();
	}
	
	public static Integer getMaxCentros() {
		return maxCentros;
	}
	
	public static List<Integer> getTematicasCurso(Integer i){
		return cursos.get(i).tematicas();
	}
	
	public static Integer getNumTematicasCurso(Integer i) {
		return getTematicasCurso(i).size();
	}
	
	public static Integer getTematicaEnCurso(Integer i, Integer j) {
		Integer res = 0;
		if(cursos.get(i).tematicas().contains(getTematicas().get(j))) {
			res = 1;
		}else {
			res = 0;
		}
		return res;
	}
	
	public static Double getPrecioInscripcion(Integer i) {
		return cursos.get(i).precio();
	}
	
	public static Integer getCentroCurso(Integer i) {
		return cursos.get(i).centro();
	}
	
	public static List<Integer> getCentros(){
		Set<Integer> res = new HashSet<>();
		for(Curso c: cursos) {
			res.add(c.centro());
		}
		return new ArrayList<>(res);
	}
	
	public static Integer getNumCentros() {
		return getCentros().size();
	}
	
	public static Integer getCursoEnCentro(Integer i, Integer k) {
		Integer res = 0;
		if(cursos.get(i).centro().equals(getCentros().get(k))) {
			res = 1;
		}else {
			res = 0;
		}
		return res;
	}
	
	public static void main(String[] args) {
		DatosEjercicio2.iniDatos("ficheros/Ejercicio2DatosEntrada2.txt");
		System.out.println(cursos);
	}
	
	
	
}
