package _datos;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import us.lsi.common.Files2;

public class DatosEjercicio3 {

public static record Investigador(String id, Integer capacidad, Integer especialidad) {
		
	public static Investigador of(String s) {
		String[] trozos = s.split(";");
		String id = trozos[0].split(":")[0].trim();
		Integer capacidad = Integer.valueOf(trozos[0].split("capacidad=")[1].trim());
		Integer especialidad = Integer.valueOf(trozos[1].split("especialidad=")[1]);
		return new Investigador(id, capacidad, especialidad);
	}
	@Override
	public String toString() {
		return String.format("%s{capacidad=%d, especialidad=%d}",id, capacidad, especialidad);
	}
	
}

public record Trabajo(String id, Integer calidad, Map<String, Integer> reparto) {
	
	public static Trabajo of(String s) {
		String[] trozos1 = s.split("->");
		String[] trozos2 = trozos1[1].split(";");

		String id = trozos1[0].trim();
		Integer calidad = Integer.valueOf(trozos2[0].split("calidad=")[1].trim());
		
		Map<String, Integer> reparto = investigadores.stream()
				.collect(Collectors.toMap(k -> k.id, v -> 0));
		
		List<String> cs = List.of(trozos2[1].split("reparto=")[1].split(","));
		for(String c : cs) {
			reparto.put(c.split(":")[0].replace("(", ""), 
					Integer.valueOf(c.split(":")[1].replace(")", "")));
		}

		return new Trabajo(id, calidad, reparto);
	}
	
}
	
	public static List<Investigador> investigadores;
	public static List<Trabajo> trabajos;
		
	public static void iniDatos(String ruta) {
		
		investigadores = new ArrayList<>();
		trabajos = new ArrayList<>();
			
		List<String> datos = Files2.linesFromFile(ruta);
		Iterator<String> it = datos.iterator();
		
		while(it.hasNext()) {
			String linea = it.next();
			if(linea.charAt(0) == 'I') {
				investigadores.add(Investigador.of(linea));
			}else if(linea.charAt(0) == 'T'){
				trabajos.add(Trabajo.of(linea));
			}
		}
	}
	
	public static Integer getNumeroInvestigadores() {
		return investigadores.size();
	}
	public static Integer getNumeroEspecialidades() {
		Set<Integer> esp = new HashSet<>();
		for(int i = 0; i < investigadores.size(); i++) {
			esp.add(investigadores.get(i).especialidad());
		}
		return esp.size();
	}
	
	public static Integer getNumeroTrabajos() {
		return trabajos.size();
	}
	
	public static Integer getTrabajadorEspecialidad(Integer i, Integer k) {
		Integer res = 0;
		if(investigadores.get(i).especialidad() == k) {
			res = 1;
		}else {
			res = 0;
		}
		return res;
	}
	
	public static Integer getDiasDisponibles(Integer i) {
		return investigadores.get(i).capacidad();
	}
	
	public static Integer getDiasNecesariosParaTrabajo(Integer j, Integer k) {
		String id = trabajos.get(j).id();
		Integer n = trabajos.get(k).reparto.get(id);
		return n;
	}
	
	public static Integer getCalidadTrabajo(Integer j) {
		return trabajos.get(j).calidad();
	}
	
	public static Integer getC() {
		return investigadores.stream().map(x->x.capacidad()).max(Comparator.naturalOrder()).get()+1;
	}
	
	public static void main(String[] args) {
		DatosEjercicio3.iniDatos("ficheros/Ejercicio3DatosEntrada1.txt");
		System.out.println(investigadores);
		System.out.println(trabajos);
	}
}
