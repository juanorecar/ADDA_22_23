package ejercicio1;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import _datos.DatosEjercicio1;
import _datos.DatosEjercicioCafes;
import _datos.DatosEjercicioCafes.Tipo;
import _datos.DatosEjercicioCafes.Variedad;
import _soluciones.SolucionCafes;
import _soluciones.SolucionEjercicio1;
import us.lsi.ag.ValuesInRangeData;
import us.lsi.ag.agchromosomes.ChromosomeFactory.ChromosomeType;


public class InRangeEjercicio1AG implements ValuesInRangeData<Integer, SolucionCafes>{
	
	
	public InRangeEjercicio1AG(String fichero) {
		DatosEjercicioCafes.iniDatos(fichero);
	}

	@Override
	public Integer size() {
		return DatosEjercicioCafes.getNumVariedades();
	}

	@Override
	public ChromosomeType type() {
		return ChromosomeType.Range;
	}

	@Override
	public Double fitnessFunction(List<Integer> ls) {
		double goal = 0;
		double error = 0;
		
		Map<String, Double> ls_pesos = new HashMap<>();
		
		for(int i = 0; i < ls.size(); i++) {
			if(ls.get(i)>0) {
				goal += ls.get(i) * DatosEjercicioCafes.getListaVariedades().get(i).beneficio();
				Variedad variedad = DatosEjercicioCafes.getListaVariedades().get(i);
				Map<String, Double> cafeMezcla = variedad.porcentajes();
				for(Map.Entry<String, Double> entry : cafeMezcla.entrySet()){
					String id = entry.getKey();
					Double peso = entry.getValue();
					peso = peso * ls.get(i);
					ls_pesos.put(id, peso);
				}
			}
		}
		error = penalizacion(ls_pesos);
		
		return goal -1000*error;
	}
	
	public static Double penalizacion(Map<String, Double> map) {
		
		Double penalizacion = 0.;
		for(Map.Entry<String, Double> entry:map.entrySet()) {
			for(Tipo t : DatosEjercicioCafes.getListaTipos()) {
				if(t.id() == entry.getKey()) {
					Double kilosDisponibles = t.kgDisponibles().doubleValue();
					if(kilosDisponibles<entry.getValue()) {
						Double sobras = entry.getValue() - kilosDisponibles;
						penalizacion += sobras;
					}
				}
			}
		}
		return penalizacion;
	}

	@Override
	public SolucionCafes solucion(List<Integer> ls) {
		return SolucionCafes.of(ls);
	}

	@Override
	public Integer max(Integer i) {
		return DatosEjercicioCafes.getKilogramosDisponibles(i);
	}

	@Override
	public Integer min(Integer i) {
		return 0;
	}

}
