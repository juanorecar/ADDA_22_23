package ejercicio1;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import _datos.DatosEjercicioCafes;
import _datos.DatosEjercicioCafes.Tipo;
import _datos.DatosEjercicioCafes.Variedad;
import us.lsi.gurobi.GurobiLp;
import us.lsi.gurobi.GurobiSolution;
import us.lsi.solve.AuxGrammar;

public class Ejercicio1PLE {
	
	public static List<Tipo> getListaTipos(){
		return DatosEjercicioCafes.getListaTipos();
	}
	
	public static List<Variedad> getListaVariedades(){
		return DatosEjercicioCafes.getListaVariedades();
	}
	
	public static Integer getNumTipos() {
		return DatosEjercicioCafes.getNumTipos();
	}
	
	public static Integer getNumVariedades() {
		return DatosEjercicioCafes.getNumVariedades();
	}
	
	public static Integer getKilogramosDisponibles(Integer j) {
		return DatosEjercicioCafes.getKilogramosDisponibles(j);
	}
	
	public static Integer getBeneficio(Integer i) {
		return DatosEjercicioCafes.getBeneficio(i);
	}
	
	public static Double getPorcentaje(Integer j, Integer i) {
		return DatosEjercicioCafes.getPorcentaje(j, i);
	}
	
public static void ejercicio1_model() throws IOException {
		
		for(int i = 1; i <= 3; i++) {
			DatosEjercicioCafes.iniDatos("ficheros/Ejercicio1DatosEntrada" + i +".txt");
			
			AuxGrammar.generate(Ejercicio1PLE.class,"lsi_models/Ejercicio1.lsi","gurobi_models/Ejercicio1-" + i + ".lp");
			GurobiSolution solution = GurobiLp.gurobi("gurobi_models/Ejercicio1-" + i + ".lp");
			Locale.setDefault(new Locale("en", "US"));
			System.out.println(solution.toString((s,d)->d>0.));
		}
		
		
	}

	public static void main(String[] args) throws IOException {
		
		ejercicio1_model();

	}
}
