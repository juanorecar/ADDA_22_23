module pi42223 {
	requires transitive grafos;
	requires transitive geneticos;
	
	exports _datos;
	exports _soluciones;
	exports ejemplo1;
	exports ejemplo2;
	exports ejemplo3;
	exports ejercicio1;
	exports ejercicio2;
	exports ejercicio3;
}