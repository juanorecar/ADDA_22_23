package us.lsi.geometria;

public class TestPunto2D {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r = Punto2D.of(2., 3.).compareTo(Punto2D.of(2.,3.));
		System.out.println(r);
	}
}
