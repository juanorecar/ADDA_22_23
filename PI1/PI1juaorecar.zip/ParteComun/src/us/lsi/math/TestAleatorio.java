package us.lsi.math;

public class TestAleatorio {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		Double alfa = 0.97;
		Double t0 = 100.;
		Double incr = 1.;
		Double pf = 0.01;
		Double n = Math.log(-incr/(t0*Math.log(pf)))/Math.log(alfa);
		System.out.println(n);
		System.out.println(-1./Math.log(0.99));
*/      Integer e = 14;
		System.out.println(e+","+Math2.numeroDeBits(e));
		}

}
