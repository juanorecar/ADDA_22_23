package us.lsi.common;

public interface TriPredicate<A,B,C> {
	
	Boolean test(A e1, B e2, C e3);

}
