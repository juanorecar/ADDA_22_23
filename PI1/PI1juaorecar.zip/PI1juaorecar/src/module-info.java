module pi1 {
	requires partecomun;
	requires datos_compartidos;
}