module Practica_individual_1_jossigizq {
	
	requires datos_compartidos;
	requires partecomun;
	
}