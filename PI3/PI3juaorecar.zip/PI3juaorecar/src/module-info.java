module PI3juaorecar {
	requires transitive grafos;
	requires org.jgrapht.core;
	requires datos_compartidos;
	
}