package datos;

public enum Relacion {
	HERMANOS, PRIMOS, OTROS
}
