package test;


import org.jgrapht.Graph;
import datos.Carretera;
import datos.Ciudad;
import ejemplos.ejemplo1;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

import java.util.function.Predicate;



public class TestEjemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testEjemplo1("Andalucia");
		testEjemplo1("Castilla La Mancha");
	}
	public static void testEjemplo1(String file) {
		//Leer los datos
		//Grafo con vertices ciudad y aristas carretera
		Graph<Ciudad, Carretera> g =
				GraphsReader.newGraph("ficheros/" + file + ".txt",
						Ciudad::ofFormat, Carretera::ofFormat, Graphs2::simpleGraph);
		
		//Generar el archivo.gv
		String fileRes = "resultados/ejemplo1/" + file + ".gv";
		GraphColors.toDot(g, fileRes, //Grafo y carpeta destino
				v->v.nombre(), e->e.nombre(),		//Etiquetas del grafo (Para poner por ejemplo Km usar e->e.km().toString())
				v->GraphColors.color(Color.black), e->GraphColors.color(Color.black));	//Estilos del grafo		
		
		
		//1b.i). Ciudades cuyo nombre contiene la letra “e”, y carreteras con menos de
		//200 km de distancia.
		Predicate<Ciudad> pv1 = c->c.nombre().contains("e"); 	//Para los vertices
		Predicate<Carretera> pa1 = a->a.km()<200;				//Para las aristas
		ejemplo1.crearVista(file, g, pv1, pa1, "PrimerPredicado");
		
		
		//1b.ii. Ciudades que poseen menos de 500.000 habitantes, y carreteras cuya
		//ciudad origen o destino tiene un nombre de más de 5 caracteres y
		//poseen más de 100 km de distancia.
		Predicate<Ciudad> pv2 = c->c.habitantes()<500000;
		Predicate<Carretera> pa2 = a->a.km()>100 && 
				(g.getEdgeSource(a).nombre().length()>5 || g.getEdgeTarget(a).nombre().length()>5);//Obtenemos vertices origen y destino -> su nombre -> nombre mayor 5?
		ejemplo1.crearVista(file, g, pv2, pa2, "Segundo Predicado");
				
	}
	
	
	
}
