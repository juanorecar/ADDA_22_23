package test;

import org.jgrapht.graph.SimpleWeightedGraph;

import datos.Carretera;
import datos.Ciudad;
import ejemplos.ejemplo2;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;

public class TestEjemplo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testEjemplo2("Andalucia","Sevilla","Almeria");
	}
	
	public static void testEjemplo2(String file, String origen, String destino) {
		//Leer los datos
		//Grafo con vertices ciudad y aristas carretera
		//Ahora queremos que sea SimpleWeightedGraph
		SimpleWeightedGraph<Ciudad, Carretera> g =
			GraphsReader.newGraph("ficheros/" + file + ".txt",
			Ciudad::ofFormat, Carretera::ofFormat, Graphs2::simpleWeightedGraph, 
			Carretera::km); //funcion para los pesos
		ejemplo2.apartadoA(g, file);
		ejemplo2.apartadoB(g, file, origen, destino);
		ejemplo2.apartadoC(g, file);
		ejemplo2.apartadoD(g, file);
	}
}
