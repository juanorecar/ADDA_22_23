/**
 * 
 */
/**
 * @author Cristian
 *
 */
module ClasePI3 {
	requires transitive grafos;
	requires org.jgrapht.core;
}