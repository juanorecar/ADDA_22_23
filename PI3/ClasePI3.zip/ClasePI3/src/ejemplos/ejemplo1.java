package ejemplos;
import java.util.function.Predicate;

import datos.Carretera;
import datos.Ciudad;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.graphs.Graphs2;
import us.lsi.graphs.GraphsReader;
import us.lsi.graphs.views.SubGraphView;
import org.jgrapht.Graph;

public class ejemplo1 {
	// 1. A partir de un grafo no dirigido y ponderado cuyos vértices son ciudades y cuyas
	// aristas son carreteras obtener:
	
	/*1a) Obtener un subgrafo con los vértices que cumplen una propiedad y las
	aristas que cumplen otra propiedad dada. NO debe crear un grafo nuevo, sino
	obtener una vista del grafo original. Muestre el subgrafo resultante
	configurando su apariencia de forma que se muestren los vértices en los que
	inciden más de 1 arista de un color diferente al resto de vértices.*/
	
	//1º (En el test) Leer datos de entrada GraphsReader.newGraph() -> objeto de tipo grafo, 
	//GraphColors.toDot() -> Archivo.gv, con Graphviz online visualizamos el grafo(no con eclipse)
	
	
	//2º Crear vista aplicando la condicion del enunciado
	public static void crearVista(String file, Graph<Ciudad, Carretera> g, 
			Predicate<Ciudad> pv, Predicate<Carretera> pa, String nombreVista) {
		
		Graph<Ciudad, Carretera> vista = SubGraphView.of(g, pv, pa);
		
		String fileRes = "resultados/ejemplo1/" + file + nombreVista + ".gv";
		GraphColors.toDot(vista, fileRes,
				v->v.nombre(), e->e.nombre(),
				v->GraphColors.colorIf(Color.red, vista.edgesOf(v).size()>1),
				e->GraphColors.color(Color.black));//Del enunciado
		System.out.println("Se ha generado" + fileRes);
	}
	
	
}
