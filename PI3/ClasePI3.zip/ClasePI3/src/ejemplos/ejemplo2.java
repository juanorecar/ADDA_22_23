package ejemplos;
import org.jgrapht.graph.SimpleWeightedGraph;

import java.util.List;
import java.util.Set;

import org.jgrapht.Graph;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.connectivity.ConnectivityInspector;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;

import datos.Carretera;
import datos.Ciudad;
import us.lsi.colors.GraphColors;
import us.lsi.colors.GraphColors.Color;
import us.lsi.colors.GraphColors.Style;
import us.lsi.graphs.Graphs2;

public class ejemplo2 {
	//2. A partir de un grafo no dirigido y ponderado cuyos vértices son ciudades y cuyas
	//aristas son carreteras, se pide:
	
	
	/*2a) Obtener un nuevo grafo que contenga los mismos vértices y sea -completo-. Las
	nuevas aristas tendrán un peso muy grande. Muestre el grafo resultante
	configurando su apariencia de forma que se resalten las nuevas aristas y los
	vértices de dichas aristas.*/
	
	//Un grafo completo es un grafo donde todos los vertices estan conectado a todos los otros mediante aristas
	//Salgan las aristas resaltadas asi como los vertices incididos
	
	public static void apartadoA(SimpleWeightedGraph<Ciudad, Carretera> gf, String file) {
		Graph<Ciudad, Carretera> gCompleto = Graphs2.explicitCompleteGraph(gf, 	//Grafo original
				1000., 															//Peso de las aristas grande
				Graphs2::simpleWeightedGraph, 									//Creador del grafo
				()->Carretera.of(1000.),										//Factoria
				Carretera::km);													//nose
		
		String fileRes = "resultados/ejemplo2/" + file + "A.gv";
		GraphColors.toDot(gCompleto, fileRes, 		//Grafo y ruta
				v->v.nombre(), e->"",				//Etiquetas vertices y aristas
				//Obtener conjunto de aristas, pasarla a stream, iterando sobre ellas si alguna tiene un peso de mil se colorea el vertice de azul
				v->GraphColors.colorIf(Color.blue, gCompleto.edgesOf(v).stream().anyMatch(e->e.km()==1000.)), 
				e->GraphColors.colorIf(Color.blue, gCompleto.getEdgeWeight(e)==1000.)   //Aquellas aristas con peso 1000 (nuevas) las colorea en azul
				);		
		System.out.println("Se ha generado" + fileRes);
	}
	
	
	
	
	
	/*2b) A partir del grafo original, dados dos vértices v1 y v2 de dicho grafo obtener
	el camino mínimo para ir de v1 a v2. Muestre el grafo original configurando
	su apariencia de forma que se resalte el camino mínimo para ir de v1 a v2.*/
	
	public static void apartadoB(SimpleWeightedGraph<Ciudad, Carretera> gf, String file,
			String c1, String c2) { 
		Ciudad origen = ciudad(gf, c1);
		Ciudad destino = ciudad(gf, c2);
		//Algoritmo camino min
		DijkstraShortestPath<Ciudad,Carretera> alg = new DijkstraShortestPath<>(gf);
		//Camino segun algoritmo
		GraphPath<Ciudad,Carretera> gp = alg.getPath(origen, destino);
		
		String fileRes = "resultados/ejemplo2/" + file + "B.gv";
		GraphColors.toDot(gf, fileRes,
				v->v.nombre(), e->e.nombre(), 											//Etiquetas
				v->GraphColors.styleIf(Style.bold, gp.getVertexList().contains(v)),		//Estilos vertices poner en negrita si contiene v
				e->GraphColors.styleIf(Style.bold, gp.getEdgeList().contains(e))
				);
		
		System.out.println("Se ha generado" + fileRes);
	}
	
	//Nuestros vertices son de tipo ciudad, asi que creamos un metodo que devuelva una ciudad a partir de un string
	public static Ciudad ciudad(Graph<Ciudad,Carretera> g, String nombre) {
		return g.vertexSet().stream().filter(c->c.nombre().equals(nombre)).findFirst().get(); 
		//Le pasamos grafo y nombre ciudad filtra aquel vertice cuyo nombre sea igual que el string pasado, devuelve el vertice ciudad
	}
	
	
	
	
	
	//2c) Obtener un nuevo grafo dirigido con los mismos vértices y que por cada arista
	//original tenga dos dirigidas y de sentido opuesto con los mismos pesos.
	
	//Entre ciudades conectadas, crear dos aristas una de ida y otra de vuelta
	//Se ha modificado datos/Carretera añadiendo metodo factoria
	
	public static void apartadoC(SimpleWeightedGraph<Ciudad,Carretera> gf, String file) {
		Graph<Ciudad,Carretera> g =
				Graphs2.toDirectedWeightedGraph(gf,   								//Grafo
						//Por cada carretera(arista) usando el metodo que nos cree otra arista con mismo km y nombre
						(Carretera a) -> Carretera.of(a.km(), a.nombre()));  		
		
		
		String fileRes = "resultados/ejemplo2/" + file + "C.gv";
		GraphColors.toDot(g, fileRes,
				v->v.nombre(), e->e.nombre() + " - " + e.km().toString(),       //En las carreteras vertices enseña nombre y km (pasamos km a string)
				v->GraphColors.color(Color.black), 
				e->GraphColors.color(Color.black));
		
		System.out.println("Se ha generado" + fileRes);
	}
	
	
	
	
	
	/*2d) Calcule las componentes conexas del grafo original. Muestre el grafo original
	configurando su apariencia de forma que se coloree cada componente conexa
	de un color diferente.*/
	
	public static void apartadoD(SimpleWeightedGraph<Ciudad,Carretera> gf, String file) {
		ConnectivityInspector<Ciudad,Carretera> p = new ConnectivityInspector<>(gf);
		List<Set<Ciudad>> ls = p.connectedSets(); //Lista de conjunto de ciudades conexas
		System.out.println("Hay " + ls.size() + " componentes conexas"); //El numero de conjunto es el numero de componentes conexas
		
		String fileRes = "resultados/ejemplo2/" + file + "D.gv";
		GraphColors.toDot(gf, fileRes,
				v->v.nombre(), e->e.nombre(),
				v->GraphColors.color(asignaColor(v,ls,p)),
				//Para saber de que color pintar la arista, cogemos el vertice de origen y le aplicamos el mismo color que a este
				e->GraphColors.color(asignaColor(gf.getEdgeSource(e),ls,p))			
				);
		System.out.println("Se ha generado" + fileRes);
	}
	
	//Funcion auxiliar para apartado 2d) para colorear cada componente conexa de un color
	public static Color asignaColor(Ciudad v, List<Set<Ciudad>> ls,
			ConnectivityInspector<Ciudad,Carretera> alg) {
		Color[] vc = Color.values();
		Set<Ciudad> s = alg.connectedSetOf(v);
		return vc[ls.indexOf(s)];
	}
	
}
